package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TestStep {
	int a=9, b=9, res;
	
	@Given("^I have variable a$")
	public void i_have_variable_a() throws Exception {
	
		System.out.println("Print "+ a);
	 }
	
	@And("^I have variable b$")
	public void i_have_variable_b() throws Exception {
		System.out.println("Print b "+b);
	 }
	
	@When("^I multiply a and b$")
	public void i_multiplication_a_and_b() throws Exception {
		res=a*b;
		System.out.println("Print a*b");
	 }
	
	@Then("^I display the Result$")
	public void i_display_the_Result() throws Exception {
	 System.out.println("Display a*b= "+res);
	 }
	
}
