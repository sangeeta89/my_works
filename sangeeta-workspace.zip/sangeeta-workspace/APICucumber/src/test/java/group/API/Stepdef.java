package group.API;

//import io.restassured.RestAssured.*;
//import io.restassured.matcher.RestAssuredMatchers.*;
//import org.hamcrest.Matchers.*;

import io.cucumber.java.en.Given;

public class Stepdef {

	
	@Given("^I Perform GET operation \"([^\"]*)\"$")
	public void iPerformGEToperation(String arg[]) throws Throwable {

		
	
	}
}
