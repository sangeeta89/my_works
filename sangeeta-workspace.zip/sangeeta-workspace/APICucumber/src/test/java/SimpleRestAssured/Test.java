package SimpleRestAssured;
/*
import java.net.*;

import java.io.*;

 public class Test {

 

public static void main(String[] args) throws IOException{

 

	try {
	
	String dummyServer = "guru99.com";
	
	System.out.println("Connecting to server - \""+dummyServer+"\" which I know does not exist.");
	
	Socket mySocket = new Socket(dummyServer,9999);
	
	} catch (UnknownHostException uhe) {
	
	uhe.printStackTrace();
	
	}        
	
	 
	
	try {
	
	String realServer = "demo.guru99.com";
	
	System.out.println("Connecting to server - \""+realServer+"\" which exists!");
	
	Socket mySocket = new Socket(realServer,8080);
	
	} catch (ConnectException ce) { ce.printStackTrace();}
	 
	}
}*/