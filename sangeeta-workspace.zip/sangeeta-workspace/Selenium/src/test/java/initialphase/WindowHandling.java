package initialphase;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class WindowHandling {
	public static WebDriver driver;
	public static String browser="chrome";
	

		void setup() throws Exception {
			
			if(browser.equalsIgnoreCase("edge")) {
				WebDriverManager.edgedriver().setup();
				driver=new EdgeDriver();
			}
			else if (browser.equalsIgnoreCase("chrome"))
			{
				WebDriverManager.chromedriver().setup();
				driver=new ChromeDriver();
			}
		
		//	System.setProperty("webdriver.chrome.driver","C:/Users/705877/OneDrive - Cognizant/Documents/tools/chromedriver_win32/chromedriver.exe");		
			driver.manage().window().maximize();
			driver.get("https://www.flipkart.com/");
			System.out.println("Main page title:"+driver.getTitle());
		}
	

	void addfunctions() throws InterruptedException, AWTException{
	
			WebElement loginpopup=driver.findElement(By.xpath("//button[@class='_2KpZ6l _2doB4z']"));
			loginpopup.click();
			Thread.sleep(2000);
			WebElement searchbox=driver.findElement(By.xpath("//*[contains(@title,'Search')]"));
			searchbox.click();
			Thread.sleep(1000);
			searchbox.sendKeys("sony a6400 camera");
			Thread.sleep(2000);
			searchbox.submit();
			Thread.sleep(2000);
			//wait for 10 seconds
//			WebDriverWait logWait = new WebDriverWait(driver, 10);
//			logWait.until(ExpectedConditions.presenceOfElementLocated(By)); 
			WebElement prodUrl=driver.findElement(By.xpath("//div[contains(text(),'SONY Alpha ILCE-6400L')]"));
			prodUrl.click();
			Thread.sleep(2000);
	        Robot robot = new Robot();

	        // Scroll Down using Robot class
	        robot.keyPress(KeyEvent.VK_PAGE_DOWN);
	        robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
	        
			System.out.println("Scrolling");
			List<WebElement> getDetails = driver.findElements(By.xpath("//div[@class='_3dtsli']/descendant::div"));
			for (int i=0; i<getDetails.size();i++){
			      System.out.println("Specifications :" + getDetails.get(i).getText());
			      System.out.println("Jumped to element");
			    }
			
			
			
			//driver.findElement(By.xpath("//*[contains(@title,'Search')]")).sendKeys("pink noise smartwatch"));


		}	 

		
		void teardown() {
			driver.quit();
			
		}
	

	public static void main(String ar[]) throws Exception {
		WindowHandling ob= new WindowHandling();
		ob.setup();
		ob.addfunctions();
		ob.teardown();
	}

}

