package initialphase;

import org.openqa.selenium.WebDriver;

public class HTMLUnit {
	void driv() {
		WebDriver driver=new HTMLUnitDriver();
		driver.get("https://www.google.com/");
		driver.close();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
