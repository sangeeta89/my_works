package initialphase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigation {
	public static WebDriver driver;
	
	void startup() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\705877\\OneDrive - Cognizant\\Documents\\tools\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://www.swiggy.com/");
		
	}
	void navigatebackforth() {
		driver.navigate().forward();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
