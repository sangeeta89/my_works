package utils;

public class LoggingService {
	public void logs(String message) {
		System.out.println(message);
	}

}
